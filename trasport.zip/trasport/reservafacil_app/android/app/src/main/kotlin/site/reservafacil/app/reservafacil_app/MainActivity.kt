package site.reservafacil.app.reservafacil_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
