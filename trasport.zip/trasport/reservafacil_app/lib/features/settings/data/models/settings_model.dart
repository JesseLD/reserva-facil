
class SettingsModel {
  SettingsModel();
}
