
class SearchModel {
  SearchModel();
}
