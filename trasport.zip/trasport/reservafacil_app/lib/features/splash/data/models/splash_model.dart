
class SplashModel {
  SplashModel();
}
