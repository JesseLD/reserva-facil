part of 'cli_commands.dart';

// Web-related constants
const String _webFolder = 'web/';
const String _webSplashFolder = '${_webFolder}splash/';
const String _webSplashImagesFolder = '${_webSplashFolder}img/';
const String _webIndex = '${_webFolder}index.html';
