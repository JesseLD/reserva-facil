@JS()
library remove_splash_from_web;

import 'dart:js_interop';

@JS("removeSplashFromWeb")
external void removeSplashFromWeb();
