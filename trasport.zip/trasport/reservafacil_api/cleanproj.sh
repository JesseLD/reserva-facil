#!/bin/bash

rm -rf node_modules
rm -rf package-lock.json
rm -rf dist

echo "Cleared the project"
 