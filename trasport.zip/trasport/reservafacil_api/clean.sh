#!/bin/bash

rm -rf dist

echo "Cleaned up the dist directory"