<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/alpinejs" defer></script>
  <script src="https://cdn.jsdelivr.net/npm/htmx.org@1.9.4"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="shortcut icon" href="<?= asset("images/favicon.svg") ?>" type="image/x-icon">

  <title><?= page_title(); ?></title>
</head>