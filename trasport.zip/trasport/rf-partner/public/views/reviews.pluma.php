<?php

extend('auth');
section('content');
set_title('Avaliações');

/**
 * Customer
 * date
 * partySize
 * status
 * id
 * 
 */
?>

<section class="">
  <div class="bg-white shadow rounded-lg p-4 w-full flex gap-4 mb-8">
    <h2 class="text-2xl font-semibold text-gray-800 ">Avaliações e Comentários</h2>


  </div>

  

</section>

<?php endSection(); ?>