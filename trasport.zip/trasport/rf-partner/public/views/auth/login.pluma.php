<?php
extend('app');
set_title('Login');

section('content');
?>

<h2>Login Page!</h2>

<?php endsection(); ?>