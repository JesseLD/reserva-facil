module.exports = {
  content: ["./public/views/**/*.php", "./app/**/*.php"],
  theme: {
    extend: {},
  },
  plugins: [],
};
