<?php

namespace App\Requests;

use Core\Validator;

class ShopkeeperRequest
{
    public static function rules(): array
    {
        return [
            // 'field' => 'required|string|max:255',
        ];
    }

    public static function validate(array $data): array
    {
        return Validator::validate($data, self::rules());
    }
}
