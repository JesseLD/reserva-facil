<?php

namespace App\Models;

use PDO;

class User extends BaseModel
{
    protected static string $table = 'Users';
    
}
