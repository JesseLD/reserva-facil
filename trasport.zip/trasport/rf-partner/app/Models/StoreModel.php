<?php

namespace App\Models;

class Store extends BaseModel
{
    protected static string $table = 'Store';
}
