<?php

namespace App\Models;

class StateModel extends BaseModel
{
  protected static string $table = 'States';
}
