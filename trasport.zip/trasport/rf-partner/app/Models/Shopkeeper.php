<?php

namespace App\Models;

class Shopkeeper extends BaseModel
{
    protected string $table = 'shopkeepers';
}
