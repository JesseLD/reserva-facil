<?php

namespace App\Models;

class StoreCategoryModel extends BaseModel
{
  protected static string $table = 'StoreCategories';
}
