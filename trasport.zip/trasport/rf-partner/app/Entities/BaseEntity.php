<?php

namespace App\Entities;

class BaseEntity
{
  // This is a base entity class
  // This class is used to define the base entity properties
}
